package com.sltc.soa;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.ws.Endpoint;
import java.io.FileReader;
import java.io.IOException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public class DemoWS
{


    @WebMethod
    public double currencyConverter(String s_currency,double s_amount,String t_currency) throws IOException, ParseException {
        JSONParser parser = new JSONParser();//create jsonparser class object
        Object obj = parser.parse(new FileReader("currency.json"));//read the json fle and assign the object
        JSONObject jsonObject = (JSONObject) obj;
        jsonObject= (JSONObject) jsonObject.get("rates");//get the rates json object
        double s_val = Double.parseDouble(String.valueOf(jsonObject.get(s_currency)));//get the user enter currency code relevant currency rate
        double t_val = Double.parseDouble(String.valueOf(jsonObject.get(t_currency)));//get the user enter currency code relevant currency rate

        double div = t_val/s_val;//get the rate of currency pair of user entered
        double t_amount = div*s_amount;//get the target amount

        return t_amount;
    }

    public static void main(String[] args){
        Endpoint.publish("http://localhost:8888/DemoWebService", new DemoWS());
    }
}
